function  Grid = ResourceGrid(carrier, nlink)
%ResourceGrid Generate resource grid.
Grid = zeros(carrier.NSizeGrid *12, carrier.SymbolsPerSlot, nlink);
end